# APPLETRUN
![](https://img.shields.io/pypi/v/appletrun?style=for-the-badge)
![](https://img.shields.io/apm/l/vim-mode?style=for-the-badge)
![](https://img.shields.io/badge/requires-Java%20%3C%3D%208-red?style=for-the-badge)

AppletRun runs applet code from given java file in a new window

## 👉 Installation
```
pip install appletrun
```
## 👉 Usage
```
 appletrun nameOfFile.java
```
<p align="center">
<img src="https://user-images.githubusercontent.com/52039218/127250568-51bfd770-49c3-4d32-9da3-18627d9abde3.gif"/>
 </p>
